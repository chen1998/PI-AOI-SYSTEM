// static/js/defect_map.js
(function(){
  const canvas = document.getElementById('defect-map-canvas');
  if(!canvas){ console.warn('[map] canvas not found'); return; }
  const ctx = canvas.getContext('2d');

  // viewport & transforms
  const View = {
    pad: 20,
    scale: 1,
    tx: 0,
    ty: 0,
    boxZoom: false,
    box: null, // {x1,y1,x2,y2}
  };

  // --- 只新增：確保 key 顏色採用高對比色盤 ---
  function ensureKeyColors(keys){
    try {
      if (window.ColorKit && typeof ColorKit.mapKeys === 'function') {
        // 這行會依目前勾選順序給「高對比色盤」
        State.keyColors = ColorKit.mapKeys(keys || []);
      } else {
        State.keyColors = State.keyColors || {};
      }
    } catch(e){
      State.keyColors = State.keyColors || {};
    }
  }
  // ------------------------------------------------
  // === 新增：用目前 State.selectedKeys 與 State.keyColors 重繪 Key 圖例 ===
  function renderLegend(){
    const host = document.getElementById('map-legend');
    if(!host) return;
    host.innerHTML = '';
    const keys = State.selectedKeys || [];
    const palette = State.keyColors || {};

    keys.forEach(k=>{
      const color =
        palette[k] ||
        (window.ColorKit && ColorKit.typeColor ? ColorKit.typeColor(k) : '#ccc');

      const item = document.createElement('div');
      item.className = 'legend-item';

      const sw = document.createElement('span');
      sw.className = 'c';
      sw.style.background = color;

      const tt = document.createElement('span');
      tt.className = 't';
      tt.textContent = k;  // 你也可以換成更短的 key 顯示

      item.appendChild(sw);
      item.appendChild(tt);
      host.appendChild(item);
    });
  }

  function getAllowedSizes(){
    return ['S','M','L','O'].filter(s=>{
      const el = document.getElementById(`size-${s}`);
      return !el || el.checked;
    });
  }
  function getAllowedTypes(){
    const host = document.getElementById('type-filters');
    if(!host) return null;
    const cbs = host.querySelectorAll('input[type=checkbox][data-type]');
    const on = [];
    cbs.forEach(cb=>{ if(cb.checked) on.push(cb.dataset.type); });
    return on.length? on : null;
  }

  function allPoints(keys){
    const pts = [];
    const palette = State.keyColors || {};
    keys.forEach(k=>{
      const lst = State.DefectCache[k]||[];
      // 這裡改為優先使用高對比 key 顏色；沒有時才 fallback
      const col =
        palette[k] ||
        (window.ColorKit && ColorKit.typeColor ? ColorKit.typeColor(k) : Utils.hashColor(k));

      lst.forEach(d=>{
        pts.push({ k, x:+d.x, y:+d.y, size: d.size, type: d.type, color: col });
      });
    });
    return pts;
  }

  function computeBounds(points){
    if(!points.length) return { minX:0,minY:0,maxX:1,maxY:1 };
    let minX=+points[0].x, minY=+points[0].y, maxX=minX, maxY=minY;
    points.forEach(p=>{ if(p.x<minX)minX=p.x; if(p.y<minY)minY=p.y; if(p.x>maxX)maxX=p.x; if(p.y>maxY)maxY=p.y; });
    return { minX, minY, maxX, maxY };
  }

  function worldToScreen(x,y, bbox){
    const W = canvas.clientWidth, H = canvas.clientHeight;
    const w = bbox.maxX-bbox.minX || 1;
    const h = bbox.maxY-bbox.minY || 1;
    const sx = ( (x - bbox.minX) / w ) * (W - 2*View.pad) + View.pad;
    const sy = H - ( ( (y - bbox.minY) / h ) * (H - 2*View.pad) + View.pad );
    return { x: sx*View.scale + View.tx, y: sy*View.scale + View.ty };
  }
  function screenToWorld(px,py, bbox){
    const W = canvas.clientWidth, H = canvas.clientHeight;
    const x0 = (px - View.tx)/View.scale, y0 = (py - View.ty)/View.scale;
    const w = bbox.maxX-bbox.minX || 1;
    const h = bbox.maxY-bbox.minY || 1;
    const wx = ( (x0 - View.pad) / (W - 2*View.pad) )*w + bbox.minX;
    const wy = ( (H - (y0)) - View.pad ) / (H - 2*View.pad) * h + bbox.minY;
    return { x: wx, y: wy };
  }

  function drawAxes(){
    const W = canvas.clientWidth, H = canvas.clientHeight;
    ctx.save();
    ctx.strokeStyle = '#6b7280';
    ctx.lineWidth = 1;
    // X axis
    ctx.beginPath(); ctx.moveTo(8, H-12); ctx.lineTo(W-8, H-12); ctx.stroke();
    // Y axis
    ctx.beginPath(); ctx.moveTo(12, H-8); ctx.lineTo(12, 8); ctx.stroke();
    ctx.restore();
  }

  function drawAll(){
    // 每次重繪前先用高對比色重新映射 key→color
    ensureKeyColors(State.selectedKeys || []);
    renderLegend();
    // resize backing canvas to displayed size
    const rect = canvas.getBoundingClientRect();
    canvas.width = Math.max(1, Math.floor(rect.width));
    canvas.height = Math.max(1, Math.floor(rect.height));

    ctx.clearRect(0,0,canvas.width, canvas.height);
    drawAxes();

    const keys = State.selectedKeys;
    const pts = allPoints(keys);
    const bbox = computeBounds(pts);

    // filters
    const sizes = getAllowedSizes();
    const types = getAllowedTypes();

    // draw points（同 key 同色，不同 key 高對比）
    pts.forEach(p=>{
      if(sizes && !sizes.includes(p.size)) return;
      if(types && !types.includes(p.type)) return;
      const s = worldToScreen(p.x, p.y, bbox);
      const r = p.size==='S'? 1.5 : p.size==='M'? 2.2 : p.size==='L'? 3.2 : 4.2;
      ctx.fillStyle = p.color;
      ctx.beginPath(); ctx.arc(s.x, s.y, r, 0, Math.PI*2); ctx.fill();
    });

    // box
    if(View.boxZoom && View.box){
      const b = View.box;
      ctx.save();
      ctx.strokeStyle = '#10b981';
      ctx.setLineDash([5,4]);
      ctx.strokeRect(Math.min(b.x1,b.x2), Math.min(b.y1,b.y2), Math.abs(b.x2-b.x1), Math.abs(b.y2-b.y1));
      ctx.restore();
    }
  }

  // 點擊 canvas → offset tables
  function handleClick(ev){
    const rect = canvas.getBoundingClientRect();
    const px = ev.clientX - rect.left, py = ev.clientY - rect.top;

    const keys = State.selectedKeys;
    const pts = allPoints(keys);
    const bbox = computeBounds(pts);
    const world = screenToWorld(px, py, bbox);
    const off = parseFloat(document.getElementById('offsetInput')?.value || '5') || 5;

    const container = document.getElementById('map-info-container');
    if(!container) return;
    container.innerHTML = '';

    keys.forEach(k=>{
      const list = State.DefectCache[k]||[];
      const within = list.filter(d => Utils.dist(world.x, world.y, +d.x, +d.y) <= off);
      // build table
      const wrap = document.createElement('div');
      wrap.className = 'offset-table-wrap';
      const title = document.createElement('div');
      title.className = 'offset-title';
      title.textContent = k;
      wrap.appendChild(title);

      const tbl = document.createElement('table');
      tbl.className = 'table offset-defect-table small';
      const thead = document.createElement('thead');
      thead.innerHTML = '<tr><th>#</th><th>x</th><th>y</th><th>size</th><th>type</th><th>img</th></tr>';
      tbl.appendChild(thead);
      const tbody = document.createElement('tbody');
      const imgBase = State.imgBaseByKey[k]||'';
      if(within.length){
        within.forEach((d, idx)=>{
          const file = Utils.ensureJpg(d.img||'');
          const src = (file.startsWith('http')? file : (imgBase + file));
          const tr = document.createElement('tr');
          tr.innerHTML = `<td>${idx+1}</td><td>${d.x}</td><td>${d.y}</td><td>${d.size}</td><td>${d.type}</td><td class="img-cell"><img src="${src}" alt=""></td>`;
          tbody.appendChild(tr);
        });
      }else{
        const tr = document.createElement('tr');
        tr.innerHTML = `<td colspan="6" class="empty">（此 key 無符合 offset=${off} 的點）</td>`;
        tbody.appendChild(tr);
      }
      tbl.appendChild(tbody);
      wrap.appendChild(tbl);
      container.appendChild(wrap);
    });
  }

  // map controls
  const btnReset = document.getElementById('btnMapReset');
  const btnIn    = document.getElementById('btnZoomIn');
  const btnOut   = document.getElementById('btnZoomOut');
  const btnBox   = document.getElementById('btnBoxZoom');
  const btnClr   = document.getElementById('btnClearBox');

  if(btnReset) btnReset.addEventListener('click', ()=>{ View.scale=1; View.tx=0; View.ty=0; drawAll(); });
  if(btnIn)    btnIn.addEventListener('click', ()=>{ View.scale*=1.25; drawAll(); });
  if(btnOut)   btnOut.addEventListener('click', ()=>{ View.scale/=1.25; drawAll(); });
  if(btnBox)   btnBox.addEventListener('click', ()=>{ View.boxZoom = !View.boxZoom; View.box = null; drawAll(); });
  if(btnClr)   btnClr.addEventListener('click', ()=>{ View.box = null; drawAll(); });

  let dragging = false;
  canvas.addEventListener('mousedown', (ev)=>{
    if(View.boxZoom){
      const r = canvas.getBoundingClientRect();
      View.box = { x1: ev.clientX - r.left, y1: ev.clientY - r.top, x2: ev.clientX - r.left, y2: ev.clientY - r.top };
    }else{
      dragging = true; canvas.style.cursor = 'grabbing';
      View._lastX = ev.clientX; View._lastY = ev.clientY;
    }
  });
  window.addEventListener('mousemove', (ev)=>{
    if(View.boxZoom && View.box){
      const r = canvas.getBoundingClientRect();
      View.box.x2 = ev.clientX - r.left; View.box.y2 = ev.clientY - r.top;
      drawAll(); return;
    }
    if(dragging){
      View.tx += (ev.clientX - View._lastX);
      View.ty += (ev.clientY - View._lastY);
      View._lastX = ev.clientX; View._lastY = ev.clientY;
      drawAll();
    }
  });
  window.addEventListener('mouseup', (ev)=>{
    if(View.boxZoom && View.box){
      // zoom into box
      const b = View.box;
      if(b && Math.abs(b.x2-b.x1)>10 && Math.abs(b.y2-b.y1)>10){
        // simple zoom center to box center
        View.scale *= 1.4;
        View.tx -= (Math.min(b.x1,b.x2) + Math.abs(b.x2-b.x1)/2 - canvas.clientWidth/2);
        View.ty -= (Math.min(b.y1,b.y2) + Math.abs(b.y2-b.y1)/2 - canvas.clientHeight/2);
      }
      View.box = null; drawAll();
    }
    dragging = false; canvas.style.cursor = 'default';
  });

  canvas.addEventListener('click', handleClick);

  // redraw on events
  Bus.on('defect-refresh', drawAll);
  Bus.on('selection-changed', drawAll);
  Bus.on('map-refresh', drawAll);

  Bus.on('selection-changed', renderLegend);
  Bus.on('defect-refresh',    renderLegend);
  Bus.on('map-refresh',       renderLegend);

  // initial draw
  drawAll();
})();